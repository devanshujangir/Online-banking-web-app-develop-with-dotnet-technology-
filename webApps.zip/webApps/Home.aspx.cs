﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"]==null)
        {
            Response.Redirect("~/deshboard/index.aspx");
        }
        DatabaseEntities cn = new DatabaseEntities();
        string setupEmail = Session["email"].ToString();
        var userExits = cn.userTables.FirstOrDefault(a => a.Email.Equals(setupEmail));
        if (userExits.Image!=null)
        {
            byte[] abc = userExits.Image;
            string strBase64 = Convert.ToBase64String(abc);
            Image2.ImageUrl = "data:Image2.png;base64," + strBase64;
        }
        else
        {
            Image2.ImageUrl = "~/images/setup pass image.PNG";
        }


    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
        DatabaseEntities cn = new DatabaseEntities();
        string setupEmail = Session["email"].ToString();
        var userBind = cn.userCardDetails.Where(a => a.UserEmail.Equals(setupEmail));
        GridView1.DataSource = userBind.ToList();
        GridView1.DataBind();
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
    }

    protected void PagePost()
    {
        if (Page.IsPostBack)
        {
            Response.Redirect("~/Home.aspx");
            MultiView1.ActiveViewIndex = 0;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
        error1.Visible = false;
        DatabaseEntities cn = new DatabaseEntities();
        if (CheckBox1.Checked)
        {
            if (DropDownList1.SelectedItem.Text != "Select Card Type" && CardName.Text != string.Empty && CardNo.Text != string.Empty && CardExpiry.Text != string.Empty && CardCVV.Text != string.Empty)
            {
                string setupEmail = Session["email"].ToString();
                var userbind = cn.userTables.FirstOrDefault(a => a.Email.Equals(setupEmail));
                string money = userbind.Money;
                string money2 = Money.Text;
                int s = Convert.ToInt32(money);
                int b = Convert.ToInt32(money2);
                int add = s + b;
                userTable c = cn.userTables.FirstOrDefault(a => a.Email.Equals(setupEmail));
                c.Money = Convert.ToString(add);
                cn.SaveChanges();
                var exits = cn.logsTables.FirstOrDefault(a => a.userEmail.Equals(setupEmail));
                var adds = new logsTable {  Date = DateTime.Now.ToString(), Amount = Money.Text, CardHolderName = CardName.Text, CardType = DropDownList1.SelectedItem.Text, userEmail = setupEmail, Operation = "Money Added" };
                cn.logsTables.Add(adds);
                cn.SaveChanges();
                error.Text = "Money successfully added...";
                
                //CardName.Text = "";
                //CardCVV.Text = "";
                //CardExpiry.Text = "";
                //CardNo.Text = "";
                //Money.Text = "";

                string cardNos = CardNo.Text;
                var userExists = cn.userCardDetails.FirstOrDefault(a => a.CardNumber.Equals(CardNo.Text));
                if (userExists == null)
                {
                    var bind = new userCardDetail { UserEmail = setupEmail, CardNumber = CardNo.Text, CardType = DropDownList1.SelectedItem.Text, CardHolderName = CardName.Text, CardCVV = CardCVV.Text, CardExpiry = CardExpiry.Text };
                    cn.userCardDetails.Add(bind);
                    cn.SaveChanges();
                    var exitss = cn.logsTables.FirstOrDefault(a => a.userEmail.Equals(setupEmail));
                    var addss = new logsTable { Date = DateTime.Now.ToString(), Amount = Money.Text, CardHolderName = CardName.Text, CardType = DropDownList1.SelectedItem.Text, userEmail = setupEmail };
                    cn.logsTables.Add(addss);
                    cn.SaveChanges();
                    error.Text = "Money successfully added...";
                    
                    //CardName.Text = "";
                    //CardCVV.Text = "";
                    //CardExpiry.Text = "";
                    //CardNo.Text = "";
                    //Money.Text = "";

                }

            }
            else
            {
                error.Text = "Insert all values!...";
            }
        }
        else
        {
            if (DropDownList1.SelectedItem.Text != "Select Card Type" && CardName.Text != string.Empty && CardNo.Text != string.Empty && CardExpiry.Text != string.Empty && CardCVV.Text != string.Empty)
            {
                string setupEmail = Session["email"].ToString();
                userTable c = cn.userTables.FirstOrDefault(a => a.Email.Equals(setupEmail));
                var userbind = cn.userTables.FirstOrDefault(a => a.Email.Equals(setupEmail));
                string money = userbind.Money;
                string money2 = Money.Text;
                int s = Convert.ToInt32(money);
                int b = Convert.ToInt32(money2);
                int add = s + b;
                c.Money = Convert.ToString(add);
                cn.SaveChanges();
                // var bind = new userCardDetail { CardNumber = CardNo.Text, CardType = DropDownList1.SelectedItem.Text, CardHolderName = CardName.Text, CardCVV = CardCVV.Text, CardExpiry = CardExpiry.Text };
                //  cn.userCardDetails.Add(bind);
                //   cn.SaveChanges();
                var exits = cn.logsTables.FirstOrDefault(a => a.userEmail.Equals(setupEmail));
                var adds = new logsTable { Date = DateTime.Now.ToString(), Amount = Money.Text, CardHolderName = CardName.Text, CardType = DropDownList1.SelectedItem.Text, userEmail = setupEmail };
                cn.logsTables.Add(adds);
                cn.SaveChanges();
                error.Text = "Money successfully added...";
                //CardName.Text = "";
                //CardCVV.Text = "";
                //CardExpiry.Text = "";
                //CardNo.Text = "";
                //Money.Text = "";
            }
            else
            {
                error.Text = "Insert all values!...";
            }
        }
        CardName.Text = "";
        CardCVV.Text = "";
        CardExpiry.Text = "";
        CardNo.Text = "";
        Money.Text = "";
        

    }

    protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/deshboard/index.aspx");
        Session.Clear();
        Session.RemoveAll();
    }



    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        foreach (GridViewRow row in GridView1.Rows)
        {
            if (row.RowIndex==GridView1.SelectedIndex)
            {
                row.BackColor = ColorTranslator.FromHtml("Silver");
            }
            else
            {
                row.BackColor = ColorTranslator.FromHtml("White");
            }
        }
        string setupEmail = Session["email"].ToString();
        DatabaseEntities cn = new DatabaseEntities();
        string email = (GridView1.SelectedRow.FindControl("srNo") as Label).Text;
        int email2 = Convert.ToInt32(email);
        Session["ids"] = email2.ToString();
        var bind = cn.userCardDetails.FirstOrDefault(a => a.Id.Equals(email2));
        CardName.Text = bind.CardHolderName;
        CardExpiry.Text = bind.CardExpiry;
        DropDownList1.SelectedItem.Text = bind.CardType;
        CardNo.Text = bind.CardNumber;

    }

    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        MultiView1.ActiveViewIndex = 2;
    }

    protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/Home.aspx");
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            if (Session["ids"] != null)
            {
                string id = Session["ids"].ToString();
                int ids = Convert.ToInt32(id);
                using (DatabaseEntities cn = new DatabaseEntities())
                {
                    userCardDetail details = (from c in cn.userCardDetails where c.Id == ids select c).FirstOrDefault();
                    cn.userCardDetails.Remove(details);
                    cn.SaveChanges();
                    string setupEmail = Session["email"].ToString();
                    var userBind = cn.userCardDetails.Where(a => a.UserEmail.Equals(setupEmail));
                    GridView1.DataSource = userBind.ToList();
                    GridView1.DataBind();
                    Session.Remove("ids");
                    error1.Visible = true;
                    error1.Text = "Card removed";
                }
            }
            else
            {
                error1.Visible = true;
                error1.Text = "Select card first";
                
            }
        }
        catch (Exception ex)
        {
            error1.Visible = true;
            error1.Text = ex.Message+(" Please select Card first...!");
        }
        

        
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        DatabaseEntities cn = new DatabaseEntities();
        if (sendingEmail.Text!=string.Empty&&sendingAmount.Text!=string.Empty&&sendingPassword.Text!=string.Empty)
        {
            int money = Convert.ToInt32(sendingAmount.Text);
            int money2 = Convert.ToInt32(Session["money"].ToString());
            if (money2 >= money)
            {
                string setupEmail = Session["email"].ToString();
                var find = cn.userTables.FirstOrDefault(a => a.Email.Equals(setupEmail));
                if (find.Password.Equals(sendingPassword.Text))
                {
                    var userExits = cn.userTables.FirstOrDefault(a => a.Email.Equals(sendingEmail.Text));
                    if (userExits != null)
                    {
                        userTable c = cn.userTables.FirstOrDefault(a => a.Email.Equals(sendingEmail.Text));
                        int amountBefore = Convert.ToInt32(userExits.Money);
                        int amountAfter = money + amountBefore;
                        c.Money = Convert.ToString(amountAfter);
                        cn.SaveChanges();
                       
                        var bind = cn.userTables.FirstOrDefault(a => a.Email.Equals(setupEmail));
                        int amount1 = Convert.ToInt32(bind.Money);
                        int update = money2 - money;
                        userTable v = cn.userTables.FirstOrDefault(a => a.Email.Equals(setupEmail));
                        v.Money = Convert.ToString(update);
                        cn.SaveChanges();

                        var logsBindReceiver = new logsTable { Amount = Convert.ToString(money), CardHolderName = bind.FirstName + " " + bind.LastName, CardType = "-", Date = DateTime.Now.ToString(), Operation = "Money Receive", userEmail = sendingEmail.Text };
                        cn.logsTables.Add(logsBindReceiver);
                        cn.SaveChanges();

                        var logsBindSender = new logsTable {Amount=Convert.ToString(money),CardHolderName=userExits.FirstName+" "+userExits.LastName,CardType="-",Date=DateTime.Now.ToString(),Operation="Money Send",userEmail=setupEmail };
                        cn.logsTables.Add(logsBindSender);
                        cn.SaveChanges();

                        error2.Text = "You have successfully send money!";
                    }
                    else
                    {
                        error2.Text = "Enter email not found!";
                    }
                }
                else
                {
                    error2.Text = "Your password is incorrect!";
                }
                
            }
            else
            {
                error2.Text = "You don't have enough money to send other person!";
            }
        }
        else
        {
            error2.Text = "Insert all values!";
        }
    }

    private void updatemoney()
    {
        //throw new NotImplementedException();

    }
}