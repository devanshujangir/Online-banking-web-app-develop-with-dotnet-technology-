﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class viewProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        DatabaseEntities cn = new DatabaseEntities();
        string setupEmail = Session["email"].ToString();
        var userExits = cn.userTables.FirstOrDefault(a => a.Email.Equals(setupEmail));

        if (userExits.Image==null)
        {
            Image2.ImageUrl = "~/images/setup pass image.PNG";
        }
        else
        {
            byte[] abc = userExits.Image;
            string strBase64 = Convert.ToBase64String(abc);
            Image2.ImageUrl = "data:Image.png;base64," + strBase64;
        }
        
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }
}