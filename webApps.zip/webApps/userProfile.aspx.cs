﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class userProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("~/userLogin.aspx");
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        DatabaseEntities cn = new DatabaseEntities();
        string email = Session["email"].ToString();
        var userView = cn.userTables.Where(a => a.Email.Equals(email));

        GridView1.DataSource = userView.ToList();
        GridView1.DataBind();
    }

    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        DatabaseEntities cn = new DatabaseEntities();
        string email = Session["email"].ToString();
        var userView = cn.userTables.Where(a => a.Email.Equals(email));
        GridView1.DataSource = userView.ToList();
        GridView1.DataBind();
    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        DatabaseEntities cn = new DatabaseEntities();
        string email = Session["email"].ToString();
        var userView = cn.userTables.Where(a => a.Email.Equals(email));
        GridView1.DataSource = userView.ToList();
        GridView1.DataBind();
    }

    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow row = GridView1.Rows[e.RowIndex];
        int userid = Convert.ToInt32((row.FindControl("userid") as Label).Text);
        string firstname = (row.FindControl("firstnames") as TextBox).Text;
        string lastname = (row.FindControl("lastnames") as TextBox).Text;
        string dob = (row.FindControl("dobs") as TextBox).Text;
        string emails = (row.FindControl("emails") as TextBox).Text;
        string mobile = (row.FindControl("phones") as TextBox).Text;
        DatabaseEntities cn = new DatabaseEntities();
        userTable c = cn.userTables.FirstOrDefault(a => a.UserId.Equals(userid));
        c.FirstName = firstname;
        c.LastName = lastname;
        c.DateofBirth = dob;
        c.Email = emails;
        c.Phone = mobile;
        cn.SaveChanges();
        GridView1.EditIndex = -1;
        string email = Session["email"].ToString();
        var userView = cn.userTables.Where(a => a.Email.Equals(email));
        GridView1.DataSource = userView.ToList();
        GridView1.DataBind();
    }



    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string email = (GridView1.SelectedRow.FindControl("email") as Label).Text;
        //Response.Redirect("viewProfile.aspx?id=" + email);
        Server.Transfer("viewProfile.aspx?id="+email);
    }
}