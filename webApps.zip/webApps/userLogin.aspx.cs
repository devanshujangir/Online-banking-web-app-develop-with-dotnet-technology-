﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Tulpep.NotificationWindow;

public partial class userLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
       
        DatabaseEntities cn = new DatabaseEntities();
        if (username.Text!=string.Empty&&password.Text!=string.Empty)
        {
            var userExits = cn.userTables.FirstOrDefault(a => a.Email.Equals(username.Text));
            if (userExits != null)
            {
                if (userExits.Password.Equals(password.Text))
                {
                    Session["email"] = userExits.Email.ToString();
                    Session["firstName"] = userExits.FirstName.ToString();
                    Session["lastName"] = userExits.LastName.ToString();
                    Session["dob1"] = userExits.DateofBirth.ToString();
                    Session["street"] = userExits.Street.ToString();
                    Session["town"] = userExits.Town.ToString();
                    Session["city"] = userExits.City.ToString();
                    Session["zipCode"] = userExits.ZipCode.ToString();
                    Session["pass"] = userExits.Password.ToString();
                    Session["money"] = userExits.Money.ToString();
                    Session["userId"] = userExits.UserId.ToString();
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Script", "<script>alert('Welcome')</script>");
                    Response.Redirect("~/Home.aspx");

                }
                else
                {
                    error.Text = "password not match";
                }
            }
            else
            {
                error.Text = "user not found!";
            }
        }
        else
        {
            error.Text = "insert all fields";
        }
        
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
}