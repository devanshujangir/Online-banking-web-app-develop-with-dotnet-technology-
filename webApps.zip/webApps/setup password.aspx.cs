﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (password.Text != string.Empty && confirmPassword.Text != string.Empty)
        {
            if (password.Text == confirmPassword.Text)
            {
                string setupEmail = Session["setupEmail"].ToString();
                DatabaseEntities cn = new DatabaseEntities();
                userTable c = cn.userTables.FirstOrDefault(a => a.Email.Equals(setupEmail));
                c.Password = password.Text;
                cn.SaveChanges();
                Response.Redirect("~/userLogin.aspx");
            }
            else
            {
                error.Text = "Confirm password not match";
            }
        }
        else
        {
            error.Text = "Fill all fields";
        }
        
        
        
        
    }
}