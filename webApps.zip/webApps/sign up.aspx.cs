﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class sign_up : System.Web.UI.Page
{
    DatabaseEntities cn = new DatabaseEntities();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (Male.Checked)
        {
            gender.Text = Male.Text;
        }
        else
        {
            if (Female.Checked)
            {
                gender.Text = Female.Text;
            }
            else
            {
                gender.Text = "select gender";
            }
        }
        if (gender.Text!=null&&civil.SelectedItem.Text!="Select Civil"&&firstname.Text!=string.Empty&&lastname.Text!=string.Empty&&dob.Text!=string.Empty&&street.Text!=string.Empty&&town.Text!=string.Empty&&city.Text!=string.Empty&&zipcode.Text!=string.Empty&&jobtitle.Text!=string.Empty&&companyname.Text!=string.Empty&&email.Text!=string.Empty&&phone.Text!=string.Empty)
        {
            var userExits = cn.userTables.FirstOrDefault(a => a.Email.Equals(email.Text.ToString()));
            if (userExits==null)
            {
                byte[] image = FileUpload1.FileBytes;
                var add = new userTable {Image=image,Money="0",Gender=gender.Text,FirstName=firstname.Text,LastName=lastname.Text,DateofBirth=dob.Text,City=city.Text,CivilStatus=civil.SelectedItem.Text,CompanyName=companyname.Text,Email=email.Text,JobTitle=jobtitle.Text,Phone=phone.Text,Street=street.Text,Town=town.Text,ZipCode=zipcode.Text };
                cn.userTables.Add(add);
                cn.SaveChanges();
                Session["setupEmail"] = email.Text;
                error.Text = "Your registration successfully";
                Response.Redirect("~/setup password.aspx");
            }
            else
            {
                error.Text = "User already exits with this email";
            }
        }
        else
        {
            error.Text = "Please fill all fields";
        }
        
    }
    
}