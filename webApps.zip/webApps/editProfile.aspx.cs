﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class editProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       ValueLoad();
    }

    private void ValueLoad()
    {
        // throw new NotImplementedException();
        //string setupEmail = Session["email"].ToString();
        //DatabaseEntities cn = new DatabaseEntities();
        //var userExits = cn.userTables.FirstOrDefault(a => a.Email.Equals(setupEmail));
        //firstName.Text = userExits.FirstName;
        //lastName.Text = userExits.LastName;
        //dateofBirth.Text = userExits.DateofBirth;
        //street.Text = userExits.Street;
        //town.Text = userExits.Town;
        //city.Text = userExits.City;
        //zipCode.Text = userExits.ZipCode;
        Gender.Items.Add(new ListItem("Male", "Male"));
        Gender.Items.Add(new ListItem("Female", "Female"));
        civilStatus.Items.Add(new ListItem("Single", "Single"));
        civilStatus.Items.Add(new ListItem("Married", "Married"));
    }

    protected void Update_Click(object sender, EventArgs e)
    {
        if (firstName.Text != string.Empty && lastName.Text != string.Empty && city.Text != string.Empty && town.Text != string.Empty && dateofBirth.Text != string.Empty && zipCode.Text != string.Empty)
        {
            string setupEmail = Session["userId"].ToString();
            int userId = Convert.ToInt32(setupEmail);
            DatabaseEntities cn = new DatabaseEntities();
            userTable c = cn.userTables.FirstOrDefault(a => a.UserId.Equals(userId));
            c.FirstName = firstName.Text;
            c.LastName = lastName.Text;
            c.Gender = Gender.SelectedItem.Text;
            c.CivilStatus = civilStatus.Text;
            c.City = city.Text;
            c.Street = street.Text;
            c.Town = town.Text;
            c.DateofBirth = dateofBirth.Text;
            c.ZipCode = zipCode.Text;
            cn.SaveChangesAsync();
            Response.Redirect("~/viewProfile.aspx");
            
        }
        else
        {
            error.Text = "Please fill all values";
        }

    }
}