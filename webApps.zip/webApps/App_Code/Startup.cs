﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Online_Banking_Website.Startup))]
namespace Online_Banking_Website
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
